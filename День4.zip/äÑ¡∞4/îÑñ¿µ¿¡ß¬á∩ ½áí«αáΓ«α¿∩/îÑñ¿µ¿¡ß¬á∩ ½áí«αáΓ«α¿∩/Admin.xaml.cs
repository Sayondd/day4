﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Медицинская_лаборатория.bd;

namespace Медицинская_лаборатория
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        private LoginHistory[] history;
        public Admin()
        {
            InitializeComponent();
            RefreshData();
            cmFilt.ItemsSource = App.entities.
                Users.Select(c => c.login).ToList();
        }

        private LoginHistory[] SortHistory(LoginHistory[] history)//сортировка
        {
            try
            {
                if (cmSort.SelectedIndex == 0)
                    history = history.ToArray();
                if (cmSort.SelectedIndex == 1)
                    history = history.OrderBy(c => c.date).ToArray();//по возрастанию
                if (cmSort.SelectedIndex == 2)
                    history = history.
                        OrderByDescending(c => c.date).ToArray();//по убыванию
            }
            catch { }
            return history;
        }

        private LoginHistory[] FiltHistory(LoginHistory[] history)
        {
            try
            {
                history = history.Where(c => c.User.login.ToLower().
                   Contains(cmFilt.Text.ToLower())).ToArray();
            }
            catch { }
            return history;
        }

        private void RefreshData()//метод для вывода данных 
        {

            history = App.entities.LoginHistories.ToArray();
            history = SortHistory(history);
            history = FiltHistory(history);
            dgHistory.ItemsSource = history.ToList();
        }

        private void cmSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void cmFilt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            Close();
        }
    }
}
