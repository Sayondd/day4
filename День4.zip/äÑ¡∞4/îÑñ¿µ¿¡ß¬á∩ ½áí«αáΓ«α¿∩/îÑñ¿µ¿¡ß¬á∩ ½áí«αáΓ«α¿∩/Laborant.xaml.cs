﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Медицинская_лаборатория
{
    /// <summary>
    /// Логика взаимодействия для Laborant.xaml
    /// </summary>
    public partial class Laborant : Window
    {
        public Laborant()
        {
            InitializeComponent();
            //запуск таймера 
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
        }

        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();

        private void timerTick(object sender, EventArgs e)//таймер
        {
            int seconds = Convert.ToInt32(Second.Content);
            int minuts = Convert.ToInt32(Minutes.Content);
            Minutes.Content = minuts.ToString();
            if (seconds > 0)
            {
                seconds--;
                Second.Content = seconds.ToString();
            }
            else
            {
                if (minuts > 0)
                {
                    minuts--;
                    Minutes.Content = minuts.ToString();
                    seconds = 59;
                    Second.Content = seconds.ToString();
                    if (minuts == 5)
                    {
                        MessageBox.Show("До окончания сеанса осталось 5 минут");
                    }
                }
                else
                {
                    timer.Stop();
                    MainWindow mw = new MainWindow();
                    mw.Show();
                    this.Close();
                }
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
            timer.Stop();
        }
    }
}
